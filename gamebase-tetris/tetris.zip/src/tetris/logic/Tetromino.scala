package tetris.logic

abstract case class Tetromino(cellType: CellType, anchorPoint : Point, squares : List[Point]){
  def rotateLeft(): Tetromino
  def rotateRight() : Tetromino
  def moveLeft() : Tetromino
  def moveRight() : Tetromino
  def moveDown() : Tetromino
  def doHardDrop() : Tetromino
}

class standardTetromino(cellType: CellType, anchorPoint : Point, squares : List[Point]) extends Tetromino(cellType, anchorPoint, squares) {
  override def rotateLeft(): standardTetromino = {
    def rotate(p: Point) : Point = Point(p.y, -p.x)
    val squaresAfterRotation = squares.map(rotate)
    new standardTetromino(cellType, anchorPoint, squaresAfterRotation)
  }
  override def rotateRight() : standardTetromino = {
    def rotate(p: Point) : Point = Point(-p.y, p.x)
    val squaresAfterRotation = squares.map(rotate)
    new standardTetromino(cellType, anchorPoint, squaresAfterRotation)
  }

  override def moveLeft() : standardTetromino = new standardTetromino(cellType, anchorPoint + Point(-1, 0), squares)
  override def moveRight() : standardTetromino = new standardTetromino(cellType, anchorPoint + Point(1, 0), squares)
  override def moveDown() : standardTetromino =  new standardTetromino(cellType, anchorPoint + Point(0, 1), squares)
  override def doHardDrop() : standardTetromino = this // TODO implement
}

class O_Tetromino(cellType: CellType, anchorPoint : Point, squares : List[Point]) extends Tetromino(cellType, anchorPoint, squares) {
  override def rotateLeft(): O_Tetromino = this
  override def rotateRight() : O_Tetromino = this

  override def moveLeft() : O_Tetromino = new O_Tetromino(cellType, anchorPoint + Point(-1, 0), squares)
  override def moveRight() : O_Tetromino = new O_Tetromino(cellType, anchorPoint + Point(1, 0), squares)
  override def moveDown() : O_Tetromino = new O_Tetromino(cellType, anchorPoint + Point(0, 1), squares)
  override def doHardDrop() : O_Tetromino = this // TODO implement
}

class I_Tetromino(cellType: CellType, anchorPoint : Point, squares : List[Point]) extends Tetromino(cellType, anchorPoint, squares) {
  override def rotateLeft(): I_Tetromino = {
    def rotate(p: Point) : Point = Point(p.y, -p.x + 1)
    val squaresAfterRotation = squares.map(rotate)
    new I_Tetromino(cellType, anchorPoint, squaresAfterRotation)
  }
  override def rotateRight() : I_Tetromino = {
    def rotate(p: Point) : Point = Point(-p.y + 1, p.x)
    val squaresAfterRotation = squares.map(rotate)
    new I_Tetromino(cellType, anchorPoint, squaresAfterRotation)
  }

  override def moveLeft() : I_Tetromino = new I_Tetromino(cellType, anchorPoint + Point(-1, 0), squares)
  override def moveRight() : I_Tetromino = new I_Tetromino(cellType, anchorPoint + Point(1, 0), squares)
  override def moveDown() : I_Tetromino = new I_Tetromino(cellType, anchorPoint + Point(0, 1), squares)
  override def doHardDrop() : I_Tetromino = this // TODO implement
}

